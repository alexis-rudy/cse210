namespace GoalSetter
{
    public class EternalGoal : Goal
    {
        public EternalGoal(string name, string desc, int points)
            : base(name, desc, points)
        {
        }
    }
}