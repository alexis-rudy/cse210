namespace GoalSetter
{
    public class SimpleGoal : Goal
    {
        public SimpleGoal(string name, string desc, int points)
            : base(name, desc, points)
        {
        }
    }
}